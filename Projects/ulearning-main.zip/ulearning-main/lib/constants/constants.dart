const double paddingDefault = 16.0;
const double paddingSmall = 10.0;

const double borderRadiusDefault = 10.0;
const double borderRadiusSmall = 5.0;

const double fontSizeDefault = 16.0;
const double fontSizeSmall = 14.0;

const double iconSizeBox = 56.0;
const double iconSizeDefault = 24.0;
const double iconSizeSmall = 20.0;

const double elevationDefault = 5.0;
const double elevationSmall = 3.0;

const double heightDefault = 20.0;
const double heightSmall = 10.0;

const double widthDefault = 20.0;
const double widthSmall = 10.0;

