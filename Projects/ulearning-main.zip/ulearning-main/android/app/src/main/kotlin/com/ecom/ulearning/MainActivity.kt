package com.ecom.ulearning

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
