class FirebaseConst {
  static const String users = 'users';
  static const String courses = 'courses';
  
}