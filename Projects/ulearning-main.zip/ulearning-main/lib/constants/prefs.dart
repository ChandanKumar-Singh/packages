class Prefs {
  static const String theme = 'theme';
  static const String locale = 'locale';
  static const String isDark = 'isDark';


  static const String TOKEN = 'TOKEN';
  static const String USER = 'USER';
  static const String USER_ID = 'USER_ID';
  

}